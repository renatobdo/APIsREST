package br.com.ifsp.consumidorCafe;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.List;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumidorCafeApplication {

	public static void main(String[] args) throws IOException, InterruptedException{
		SpringApplication.run(ConsumidorCafeApplication.class, args);
	
	
	// Fazer uma conexão HTTP e buscar os cafes
	String url = "http://localhost:8080/cafes";
	URI endereco = URI.create(url);
	HttpClient cliente = HttpClient.newHttpClient();
	HttpRequest request = HttpRequest.newBuilder(endereco).GET().build();
	
	HttpResponse<String> response = 
			cliente.send(request, BodyHandlers.ofString());
 	String body = response.body();

	// Extrair as informações da requisição
	//System.out.println("Testes = " + body);
	//Extrair somente as informações que precisamos
	
	JsonParser parser = new JsonParser();
	List<Map<String,String>>listaDeCafes = parser.parse(body);
	
	//Exibir e manipular os dados
	for (Map<String,String> cafe: listaDeCafes) {
		System.out.println(cafe.get("id"));
		System.out.println(cafe.get("name"));
		System.out.println(cafe.get("historia"));
		System.out.println(cafe.get("sabor"));
		System.out.println(cafe.get("referencia"));
		System.out.println(cafe.get("imagem"));
	}
	
	}
}
