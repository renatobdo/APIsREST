package br.com.ifsp.cafeteria;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cafes")
public class RestApiCafeController {
	private List<Cafe> cafes = new ArrayList<>();
	
	public RestApiCafeController() {
		cafes.addAll(List.of(new Cafe("Café Arábica"),
				new Cafe("Café Bourbon"),
				new Cafe("Café Acaiá"),
				new Cafe("Café Atuaí"),
				new Cafe("Café Robusta"),
				new Cafe("Café Geisha"),
				new Cafe("Café Kona")
		));
	}
	@GetMapping
	Iterable<Cafe> getCafes(){
		return cafes;
	}
	@GetMapping("/{id}")
	Optional<Cafe> getCafeById(@PathVariable String id){
		for(Cafe c : cafes) {
			if(c.getId().equals(id)) {
				return Optional.of(c);
			}
		}
		return Optional.empty();	
	}
	@PostMapping("/cafe")
	Cafe postCafe(@RequestBody Cafe cafe) {
		cafes.add(cafe);
		return cafe;
	}
	String mensagensErro() {
		return "O id não existe";
		
	}
	
	
	@PutMapping("/cafe/{id}")
	ResponseEntity<String> putCafe(@PathVariable String id,
			@RequestBody Cafe cafe){
		int cafeIndice = -1;
		//Erro mensagem = new Erro("Id não encontrado");
		for (Cafe c: cafes) {
			if (c.getId().equals(id)) {
				cafeIndice = cafes.indexOf(c);
				cafes.set(cafeIndice, cafe);
			}
		}
		
		return (cafeIndice == -1) ?
				new ResponseEntity<String>("Não encontrado",
						HttpStatus.NOT_FOUND)
				:
				new ResponseEntity<String>("Ok Atualizado",HttpStatus.OK);
		
		
	}
	@DeleteMapping("/{id}")
	ResponseEntity<String> deleteCafe(@PathVariable String id) {
		boolean del = false;
		del = cafes.removeIf(c -> c.getId().equals(id));
		return (del) ?
				new ResponseEntity<> ("Eliminado",
						HttpStatus.OK)
				:
				new ResponseEntity<>("Não localizado!",
						HttpStatus.NOT_FOUND);
	}
	
	
	

}
