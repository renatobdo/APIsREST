package br.com.ifsp.cafeteria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeteriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
