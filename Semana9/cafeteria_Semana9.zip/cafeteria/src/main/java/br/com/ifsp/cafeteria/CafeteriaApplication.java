package br.com.ifsp.cafeteria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//https://stackoverflow.com/questions/51221777/failed-to-configure-a-datasource-url-attribute-is-not-specified-and-no-embedd
@SpringBootApplication
public class CafeteriaApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(CafeteriaApplication.class, args);
	}

}
