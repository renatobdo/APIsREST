package br.com.ifsp.cafeteria;


import org.springframework.data.repository.CrudRepository;

public interface CafeRepository extends CrudRepository<Cafe, String> {
/*
	List<Cafe> findAll();

	Optional<Cafe> findById(String id);

	boolean existsById(String id);

	void deleteById(String id);*/

}
