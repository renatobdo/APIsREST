package br.com.ifsp.cafeteria;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cafes")
public class RestApiCafeController {
	// private List<Cafe> cafes = new ArrayList<>();
	private final CafeRepository cafeRepository;

	/*
	 * public RestApiCafeController() { cafes.addAll(List.of(new
	 * Cafe("Café Arábica"), new Cafe("Café Bourbon"), new Cafe("Café Acaiá"), new
	 * Cafe("Café Atuaí"), new Cafe("Café Robusta"), new Cafe("Café Geisha"), new
	 * Cafe("Café Kona") )); }
	 */
	//https://platform.openai.com/docs/guides/images/introduction?lang=curl
	//https://platform.openai.com/account/api-keys
	//https://iphotochannel.com.br/os-5-melhores-geradores-de-imagens-com-inteligencia-artificial-ia-em-2022/
	//https://drive.google.com/drive/folders/1QE31cY3Dz95nw3Vvu1cBlX7IGsYOY6ch?usp=share_link
	// https://docs.google.com/spreadsheets/d/1HnSgIJyqTI_nIJgPWmNfMYIbaegtInpggosH4BK_uB0/edit?usp=sharing
	public RestApiCafeController(CafeRepository cafeRepository) {
		this.cafeRepository = cafeRepository;
		/*
		 * this.cafeRepository.saveAll(List.of(new Cafe("Café Arábica"), new
		 * Cafe("Café Bourbon"), new Cafe("Café Acaiá"), new Cafe("Café Atuaí"), new
		 * Cafe("Café Robusta"), new Cafe("Café Geisha"), new Cafe("Café Kona")));
		 */
	}

	@GetMapping
	Iterable<Cafe> getCafes() {
		return cafeRepository.findAll();
	}

	@GetMapping("/{id}")
	Optional<Cafe> getCafeById(@PathVariable String id) {
		return cafeRepository.findById(id);
	}

	@PostMapping("/cafe")
	Cafe postCafe(@RequestBody Cafe cafe) {

		return cafeRepository.save(cafe);
	}

	@PutMapping("/cafe/{id}")
	ResponseEntity<Cafe> putCafe(@PathVariable String id, @RequestBody Cafe cafe) {

		return (!cafeRepository.existsById(id)) ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
				: new ResponseEntity<>(cafeRepository.save(cafe), HttpStatus.OK);
	}

	@DeleteMapping("/{id}")
	void deleteCafe(@PathVariable String id) {
		cafeRepository.deleteById(id);
		return;
	}
}