create table cafe (id bigint not null auto_increment,
name varchar(255) not null,
historia varchar(5000),
sabor varchar(5000),
referencia varchar(1000),
imagem varchar(3000),

primary key (id)
);