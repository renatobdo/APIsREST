package br.com.ifsp.cafeteria.model;

public record DadosAutenticacao(String login, String senha) {

}
