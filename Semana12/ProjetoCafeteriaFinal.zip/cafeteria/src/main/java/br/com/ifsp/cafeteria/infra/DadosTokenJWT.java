package br.com.ifsp.cafeteria.infra;

public record DadosTokenJWT(String token) {}